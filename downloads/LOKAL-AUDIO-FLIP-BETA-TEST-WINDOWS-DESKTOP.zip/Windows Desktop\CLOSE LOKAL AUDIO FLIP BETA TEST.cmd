@echo off
set "PIDFILE=%~dp0lokal-audio-flip-beta.pid"
if not exist "%PIDFILE%" exit /b 0
set /p LOKALPID=<"%PIDFILE%"
taskkill /PID %LOKALPID% /T >nul 2>&1
del /q "%PIDFILE%" >nul 2>&1
exit /b 0