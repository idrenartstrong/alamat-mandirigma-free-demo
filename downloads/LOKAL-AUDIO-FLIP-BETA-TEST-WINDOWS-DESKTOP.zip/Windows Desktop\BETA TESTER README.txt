LOKAL AUDIO FLIP — BETA TEST
Created by Artstrong Javier Clarion

WINDOWS DESKTOP BETA
1. Extract the full ZIP before running.
2. Double-click: START LOKAL AUDIO FLIP BETA TEST.cmd
3. The app opens in a dedicated desktop-style Edge window.
4. When finished, double-click: CLOSE LOKAL AUDIO FLIP BETA TEST.cmd

This is a private evaluation build for sound engineers and music producers.
It is NOT the final public release.

Please test Audio-to-MIDI accuracy, Piano Roll timing, note lengths,
BPM sync, MIDI export, Sheet Music, keyboard transport shortcuts,
metronome timing, Audio Master Engine, A/B, LUFS/true peak and WAV export.

Please do not redistribute the beta package without permission.
Report the audio file type, duration, BPM, selected instrument/mode,
what happened, what you expected, and your computer specs with each issue.