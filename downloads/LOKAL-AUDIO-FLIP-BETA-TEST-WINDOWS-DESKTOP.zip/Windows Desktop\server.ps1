$ErrorActionPreference='Stop'
$root=Join-Path $PSScriptRoot 'app'
$port=5190
$prefix="http://127.0.0.1:$port/"
$pidFile=Join-Path $PSScriptRoot 'lokal-audio-flip-beta.pid'
Set-Content -Path $pidFile -Value $PID -NoNewline
$types=@{'.html'='text/html; charset=utf-8';'.js'='text/javascript; charset=utf-8';'.css'='text/css; charset=utf-8';'.json'='application/json; charset=utf-8';'.bin'='application/octet-stream';'.png'='image/png';'.jpg'='image/jpeg';'.jpeg'='image/jpeg';'.svg'='image/svg+xml'}
$listener=[Net.HttpListener]::new()
$listener.Prefixes.Add($prefix)
$listener.Start()
try {
  while($listener.IsListening){
    $ctx=$listener.GetContext()
    try{
      $rel=[Uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath.TrimStart('/'))
      if([string]::IsNullOrWhiteSpace($rel)){$rel='index.html'}
      $path=[IO.Path]::GetFullPath((Join-Path $root $rel))
      if(-not $path.StartsWith([IO.Path]::GetFullPath($root)) -or -not (Test-Path $path) -or (Get-Item $path).PSIsContainer){$path=Join-Path $root 'index.html'}
      $ext=[IO.Path]::GetExtension($path).ToLowerInvariant()
      $ctx.Response.ContentType=if($types.ContainsKey($ext)){$types[$ext]}else{'application/octet-stream'}
      $ctx.Response.Headers['Cache-Control']='no-store'
      $bytes=[IO.File]::ReadAllBytes($path)
      $ctx.Response.ContentLength64=$bytes.Length
      $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length)
    }catch{$ctx.Response.StatusCode=500}
    finally{$ctx.Response.OutputStream.Close()}
  }
} finally {
  $listener.Stop()
  Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
}