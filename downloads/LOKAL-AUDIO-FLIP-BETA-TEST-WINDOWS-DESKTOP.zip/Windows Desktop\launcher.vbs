Option Explicit
Dim sh, fso, base, ps, edge1, edge2
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
ps = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & base & "\server.ps1"""
edge1 = sh.ExpandEnvironmentStrings("%ProgramFiles(x86)%") & "\Microsoft\Edge\Application\msedge.exe"
edge2 = sh.ExpandEnvironmentStrings("%ProgramFiles%") & "\Microsoft\Edge\Application\msedge.exe"
sh.Run ps, 0, False
WScript.Sleep 1200
If fso.FileExists(edge1) Then
  sh.Run """" & edge1 & """ --app=http://127.0.0.1:5190 --start-maximized", 1, False
ElseIf fso.FileExists(edge2) Then
  sh.Run """" & edge2 & """ --app=http://127.0.0.1:5190 --start-maximized", 1, False
Else
  sh.Run "http://127.0.0.1:5190", 1, False
End If