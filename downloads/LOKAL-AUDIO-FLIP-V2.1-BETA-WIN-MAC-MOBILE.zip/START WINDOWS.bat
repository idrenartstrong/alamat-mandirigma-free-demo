@echo off
cd /d "%~dp0web"
where node >nul 2>&1 || (echo Install Node.js LTS from https://nodejs.org/ & pause & exit /b 1)
node server.mjs
pause
