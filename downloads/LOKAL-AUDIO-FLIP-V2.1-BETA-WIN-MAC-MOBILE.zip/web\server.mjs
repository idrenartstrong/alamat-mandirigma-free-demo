﻿import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { spawn } from 'child_process';

const root = path.dirname(fileURLToPath(import.meta.url));
const host = '127.0.0.1';
const port = 5185;
const types = {
  '.html':'text/html; charset=utf-8',
  '.js':'text/javascript; charset=utf-8',
  '.css':'text/css; charset=utf-8',
  '.json':'application/json; charset=utf-8',
  '.bin':'application/octet-stream',
  '.png':'image/png',
  '.jpg':'image/jpeg',
  '.jpeg':'image/jpeg',
  '.svg':'image/svg+xml',
  '.ico':'image/x-icon', '.webmanifest':'application/manifest+json'
};

function safePath(urlPath) {
  const clean = decodeURIComponent(urlPath.split('?')[0]).replace(/^\/+/, '');
  const p = path.resolve(root, clean || 'index.html');
  return p.startsWith(root) ? p : path.join(root, 'index.html');
}

const server = http.createServer((req, res) => {
  let p = safePath(req.url || '/');
  if (!fs.existsSync(p) || fs.statSync(p).isDirectory()) p = path.join(root, 'index.html');
  try {
    const ext = path.extname(p).toLowerCase();
    res.writeHead(200, {
      'Content-Type': types[ext] || 'application/octet-stream',
      'Cache-Control': 'no-store'
    });
    fs.createReadStream(p).pipe(res);
  } catch (err) {
    res.writeHead(500, {'Content-Type':'text/plain'});
    res.end(String(err));
  }
});

server.listen(port, host, () => {
  const url = `http://${host}:${port}`;
  console.log(`LOKAL MIDI FLIP V2.1 MASTERING running at ${url}`);
  setTimeout(() => spawn(process.platform === 'win32' ? 'cmd' : 'open', process.platform === 'win32' ? ['/c','start','',url] : [url], { detached:true, stdio:'ignore' }).unref(), 400);
});

