﻿LOKAL AUDIO FLIP V2.1 BETA
WINDOWS: Extract ZIP and double-click START WINDOWS.bat. Requires Node.js LTS.
MAC: Extract ZIP, chmod +x "START MAC.command", then open it. Requires Node.js LTS.
IOS/ANDROID: Serve the web folder on HTTPS. Open the link in Safari/Chrome and Add to Home Screen where supported.
This is a browser/PWA beta, not native App Store or Google Play software. Mobile DSP/performance and exports require device testing.
WEBSITE: Upload the contents of web/ to the target site directory only after backing up the existing version. Server.mjs is ONLY for local desktop use.
Created for Artstrong Javier Clarion.
