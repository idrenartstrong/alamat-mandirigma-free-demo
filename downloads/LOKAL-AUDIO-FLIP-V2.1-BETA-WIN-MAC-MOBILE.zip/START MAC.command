﻿#!/bin/sh
cd "$(dirname "$0")/web" || exit 1
command -v node >/dev/null 2>&1 || { echo "Install Node.js LTS from https://nodejs.org/"; exit 1; }
node server.mjs
