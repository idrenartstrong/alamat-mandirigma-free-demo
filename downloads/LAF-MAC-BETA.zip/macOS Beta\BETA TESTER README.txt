LOKAL AUDIO FLIP — BETA TEST
Created by Artstrong Javier Clarion

macOS BETA
For audio engineers, music producers, mixing/mastering engineers and musicians.

COMPATIBILITY
• macOS 12 Monterey or later recommended
• Apple Silicon (M1/M2/M3/M4) and Intel Macs
• Google Chrome recommended; Safari can also be used
• Internet is not required after the beta package is downloaded
• A local web server is required. The launcher automatically uses Python 3, Python, Ruby or PHP if installed.

HOW TO START
1. Extract the full ZIP.
2. Open Terminal in the extracted folder.
3. First time only, run:
   chmod +x "START LOKAL AUDIO FLIP BETA TEST.command" "CLOSE LOKAL AUDIO FLIP BETA TEST.command"
4. Double-click START LOKAL AUDIO FLIP BETA TEST.command.
5. Your browser will open LOKAL AUDIO FLIP at http://127.0.0.1:5190/
6. When finished, double-click CLOSE LOKAL AUDIO FLIP BETA TEST.command.

IF macOS BLOCKS THE LAUNCHER
Control-click the .command file, choose Open, then confirm Open.
If macOS still blocks it, go to System Settings > Privacy & Security and allow the file.

TEST THESE AREAS
Audio-to-MIDI accuracy, Piano Roll timing and note lengths, BPM sync,
MIDI export and DAW synchronization, Sheet Music / Guitar Tab / Note List,
keyboard transport shortcuts, metronome timing, Audio Master Engine,
A/B comparison, LUFS / true peak behavior and WAV export.

BETA NOTICE
This is an evaluation build and is not the final public release.
Please do not redistribute the beta package without permission.

WHEN REPORTING AN ISSUE
Include your Mac model, chip (Apple Silicon or Intel), macOS version,
browser, DAW, audio interface, source audio file type, duration, BPM,
selected instrument/mode, what happened and what you expected.

Official beta page:
https://lokalafroflip.com/lokal-audio-flip/
