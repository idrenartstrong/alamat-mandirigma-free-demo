#!/bin/bash
cd "$(dirname "$0")"
PORT=5190
ROOT="$PWD/app"
PIDFILE="$PWD/lokal-audio-flip-beta.pid"

if [ -f "$PIDFILE" ]; then
  OLD_PID=$(cat "$PIDFILE")
  if kill -0 "$OLD_PID" 2>/dev/null; then
    open "http://127.0.0.1:$PORT/"
    exit 0
  else
    rm -f "$PIDFILE"
  fi
fi

start_server() {
  "$@" >/tmp/lokal-audio-flip-beta.log 2>&1 &
  echo $! > "$PIDFILE"
  sleep 1
}

if command -v python3 >/dev/null 2>&1; then
  start_server python3 -m http.server "$PORT" --bind 127.0.0.1 --directory "$ROOT"
elif command -v python >/dev/null 2>&1; then
  start_server python -m http.server "$PORT" --bind 127.0.0.1 --directory "$ROOT"
elif command -v ruby >/dev/null 2>&1; then
  cd "$ROOT"
  start_server ruby -run -e httpd . -p "$PORT" -b 127.0.0.1
elif command -v php >/dev/null 2>&1; then
  cd "$ROOT"
  start_server php -S 127.0.0.1:"$PORT"
else
  osascript -e 'display dialog "LOKAL AUDIO FLIP needs a local web server. Please install Python 3 from python.org, then run this launcher again." buttons {"OK"} default button "OK" with icon caution'
  exit 1
fi

if [ -d "/Applications/Google Chrome.app" ]; then
  open -a "Google Chrome" "http://127.0.0.1:$PORT/"
else
  open "http://127.0.0.1:$PORT/"
fi
