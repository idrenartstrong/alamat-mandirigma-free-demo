#!/bin/bash
cd "$(dirname "$0")"
PIDFILE="$PWD/lokal-audio-flip-beta.pid"

if [ -f "$PIDFILE" ]; then
  PID=$(cat "$PIDFILE")
  if kill -0 "$PID" 2>/dev/null; then
    kill "$PID" 2>/dev/null
  fi
  rm -f "$PIDFILE"
fi

osascript -e 'display notification "LOKAL AUDIO FLIP beta server has been closed." with title "LOKAL AUDIO FLIP"'
exit 0
